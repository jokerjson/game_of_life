1.install node.js
2.find your product directory.
3.npm start...
localhost:3333